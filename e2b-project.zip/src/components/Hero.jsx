```jsx
import React from 'react';

const heroImages = [
  "https://cdn.cybassets.com/s/files/15409/ckeditor/pictures/content_611f924b-4eda-4f2f-b46e-bf6ce33b98c0.jpg",
  "https://cdn.cybassets.com/s/files/15409/ckeditor/pictures/content_168a2b94-c8aa-41e9-87e7-73fa3ba5905b.jpg",
  "https://cdn.cybassets.com/s/files/15409/ckeditor/pictures/content_e5add42f-dedb-46bd-9d6e-69f4b3bc02ce.jpg",
  "https://cdn.cybassets.com/s/files/15409/ckeditor/pictures/content_f491b12a-85f9-4715-affc-be6685cbf27a.jpg"
];

const Hero = () => {
  return (
    <section className="bg-gray-100">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2">
          {heroImages.map((src, index) => (
            <div key={index} className="w-full h-auto">
              <img src={src} alt={`Promotional banner \${index + 1}`} className="w-full h-full object-cover" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Hero;
```