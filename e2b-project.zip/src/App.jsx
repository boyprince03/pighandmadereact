```jsx
import { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import InfoSection from './components/InfoSection';
import ProductGrid from './components/ProductGrid';
import Footer from './components/Footer';
import CheckoutPage from './components/CheckoutPage';

const allProducts = [
  { id: 1, name: '【現貨】抬頭星人光柵小卡六入組_老高與小茉', price: 'NT\$250', category: '生活小物', image: 'https://cdn.cybassets.com/media/W1siZiIsIjE1NDA5L3Byb2R1Y3RzLzU2NDcxMDE2LzE3NTA4MDY0NjRfMmFjNjcyMDlkMzUzN2M1ZTllZGUucG5nIl0sWyJwIiwidGh1bWIiLCI2MDB4NjAwIl1d.png?sha=32b4907a7eb85024' },
  { id: 2, name: '【現貨】五歲抬頭手機掛繩-短-手腕繩_老高與小茉', price: 'NT\$499', category: '手機配件', image: 'https://cdn.cybassets.com/media/W1siZiIsIjE1NDA5L3Byb2R1Y3RzLzQ1OTIyNjE4LzE3MTUwNjgzMzRfODUyZjExMGU2YzllNTNkZTliY2MuanBlZyJdLFsicCIsInRodW1iIiwiNjAweDYwMCJdXQ.jpeg?sha=7942df474aba424b' },
  { id: 3, name: '【現貨】五歲抬頭手機掛繩-長-頸掛繩_老高與小茉', price: 'NT\$599', category: '手機配件', image: 'https://cdn.cybassets.com/media/W1siZiIsIjE1NDA5L3Byb2R1Y3RzLzQ2Mjg1NTkyLzE3MTUwNjgyOTlfNDA2ZGU2YmEyN2I5ZDljODJhMDYuanBlZyJdLFsicCIsInRodW1iIiwiNjAweDYwMCJdXQ.jpeg?sha=8775ac77da7250d3' },
  { id: 4, name: '【預購】老帽-5TITLE星球款_老高與小茉', price: 'NT\$799', category: '服飾', image: 'https://cdn.cybassets.com/media/W1siZiIsIjE1NDA5L3Byb2R1Y3RzLzU1Mjg5NDgxLzE3NDYxOTQ0MzdfMjI4MTBkMWU0ZGMwZDE1MjE1YmYucG5nIl0sWyJwIiwidGh1bWIiLCI2MDB4NjAwIl1d.png?sha=7d3e1e9c5a64065b' },
  { id: 5, name: '【預購】辦公桌墊_老高與小茉', price: 'NT\$850', category: '生活小物', image: 'https://cdn.cybassets.com/media/W1siZiIsIjE1NDA5L3Byb2R1Y3RzLzU1MjIxNjA2LzE3NTA1NzI2ODNfOTcyNDI2MGZjMTNlN2I4NzU1MTEucG5nIl0sWyJwIiwidGh1bWIiLCI2MDB4NjAwIl1d.png?sha=40bfafdad4a86e44' },
  { id: 6, name: '【預購】滑鼠墊_老高與小茉', price: 'NT\$450', category: '生活小物', image: 'https://cdn.cybassets.com/media/W1siZiIsIjE1NDA5L3Byb2R1Y3RzLzU1MjIxNjA1LzE3NDY0NTAwOTVfNWRhNjBkOGEwMGI3YWY3NmZmYmIucG5nIl0sWyJwIiwidGh1bWIiLCI2MDB4NjAwIl1d.png?sha=e2417641666a968e' },
  { id: 7, name: '【現貨】五歲抬頭標語襪-2色_老高與小茉', price: 'NT\$350', category: '服飾', image: 'https://cdn.cybassets.com/s/files/15409/theme/16999/assets/img/default_product.png' },
  { id: 8, name: '【現貨】五歲抬頭棒球帽-2色_老高與小茉', price: 'NT\$799', category: '服飾', image: 'https://cdn.cybassets.com/s/files/15409/theme/16999/assets/img/default_product.png' },
  { id: 9, name: '【現貨】抬頭星人壓克力鑰匙圈-2款_老高與小茉', price: 'NT\$250', category: '生活小物', image: 'https://cdn.cybassets.com/s/files/15409/theme/16999/assets/img/default_product.png' },
  { id: 10, name: '【現貨】抬頭星人貼紙組-3入_老高與小茉', price: 'NT\$150', category: '生活小物', image: 'https://cdn.cybassets.com/s/files/15409/theme/16999/assets/img/default_product.png' },
  { id: 11, name: '【現貨】抬頭星人徽章組-3入_老高與小茉', price: 'NT\$280', category: '生活小物', image: 'https://cdn.cybassets.com/s/files/15409/theme/16999/assets/img/default_product.png' },
  { id: 12, name: '【現貨】五歲抬頭漁夫帽_老高與小茉', price: 'NT\$890', category: '服飾', image: 'https://cdn.cybassets.com/s/files/15409/theme/16999/assets/img/default_product.png' },
];

function App() {
  const [displayedProducts, setDisplayedProducts] = useState(allProducts);
  const [activeFilter, setActiveFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [cart, setCart] = useState([]);
  const [view, setView] = useState('products');

  const applyFiltersAndSearch = (category, term) => {
    let products = allProducts;

    if (category !== 'all') {
      products = products.filter(p => p.category === category);
    }

    if (term.trim()) {
      products = products.filter(p => p.name.toLowerCase().includes(term.toLowerCase()));
    }

    setDisplayedProducts(products);
  };

  const handleFilterChange = (category) => {
    setActiveFilter(category);
    applyFiltersAndSearch(category, searchTerm);
  };

  const handleSearch = (term) => {
    setSearchTerm(term);
    applyFiltersAndSearch(activeFilter, term);
  };

  const addToCart = (productToAdd) => {
    setCart(prevCart => {
      const existingProduct = prevCart.find(item => item.id === productToAdd.id);
      if (existingProduct) {
        return prevCart.map(item =>
          item.id === productToAdd.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prevCart, { ...productToAdd, quantity: 1 }];
    });
  };

  return (
    <div className="bg-white font-sans">
      <Header cartItemCount={cart.reduce((count, item) => count + item.quantity, 0)} setView={setView} />
      <main>
        {view === 'products' ? (
          <>
            <Hero />
            <InfoSection 
              onFilterChange={handleFilterChange} 
              activeFilter={activeFilter}
              onSearch={handleSearch}
            />
            <ProductGrid products={displayedProducts} onAddToCart={addToCart} />
          </>
        ) : (
          <CheckoutPage cart={cart} setCart={setCart} setView={setView} />
        )}
      </main>
      <Footer />
    </div>
  );
}

export default App;
```